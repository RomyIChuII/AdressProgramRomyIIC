﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdressProgramRomyIIC.cs
{
    public partial class frmAddressProgramRomyIIC : Form
    {
        public frmAddressProgramRomyIIC()
        {
            InitializeComponent();
        }
    }
}
